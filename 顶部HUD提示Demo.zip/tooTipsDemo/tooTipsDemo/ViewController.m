//
//  ViewController.m
//  tooTipsDemo
//
//  Created by bean on 16/2/23.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "ViewController.h"
#import "DXStatusBarHUD.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray * arr = @[@"成功",@"失败",@"ing",@"hide",@"hhhh"];
    
    for (int i = 0; i<arr.count; i++)
    {
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(i*60, 100, 50, 50);
        btn.backgroundColor = [UIColor redColor];
        [btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = i+1;
        [self.view addSubview:btn];
    }
    
    
}
-(void)click:(UIButton*)btn
{
    switch (btn.tag) {
        case 1:
        {
            [DXStatusBarHUD showSuccess:@"加载数据成功！"];
        }
            break;
        case 2:
        {
            [DXStatusBarHUD showError:@"登录失败！"];
        }
            break;
        case 3:
        {
            [DXStatusBarHUD showLoading:@"正在登录中..."];
        }
            break;
        case 4:
        {
            [DXStatusBarHUD hide];
        }
            break;
        case 5:
        {
//            [DXStatusBarHUD showText:@"随便显示的文字！！！！"];
            [DXStatusBarHUD showImageName:@"chat_announce_close.png" text:@"试一试"];
        }
            break;
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
